let minesweepers = {
    rows : 12,
    cols : 24,
    num_of_stars : 55,
    star : '*',
    isPresent : true,
    colors : {1: 'green', 2: 'yellow', 3: 'blue', 4: 'maroon', 5: 'purple', 6: 'turquoise', 7: 'red', 8: 'grey'}
}

const InitGame = function () {
    minesweepers.stars = addstars();
    document.getElementById('minefield').appendChild(minesweepersTable());
}

function addstars() {
     stars = []; 
    for (let i=0; i<minesweepers.num_of_stars; i++) {
        addSinglestar(stars);
    }
    return stars;
} 

let addSinglestar = function(stars) {
    let sweeprow, sweepcol, rowItems, colItems;
    sweeprow = Math.floor(Math.random() * minesweepers.rows);
    sweepcol = Math.floor(Math.random() * minesweepers.cols);
    rowItems = stars[sweeprow];
    if (!rowItems) {
        rowItems = [];
        stars[sweeprow] = rowItems;
    }
    colItems = rowItems[sweepcol];
    
    if (!colItems) {
        rowItems[sweepcol] = true;
        return
    } 
    else {
        addSinglestar(stars);
    }
}

const  tableId =  function(i, j) {
    return 'cell-' + i + '-' + j;
}

let minesweepersTable = function () {
    let mineData, minerow;
    mineData = document.createElement('table');
    
    for (i=0; i<minesweepers.rows; i++) {
        minerow = document.createElement('tr');
        for (j=0; j<minesweepers.cols; j++) {
           let td = document.createElement('td');
            td.id = tableId(i, j);
            minerow.appendChild(td);
            createCellItems(td, i, j);
        }
        mineData.appendChild(minerow);
    }
    return mineData;
}

let createCellItems = function (td, i, j) {
    td.addEventListener('mousedown', function(event) {
        if (!minesweepers.isPresent) {
            return;
        }
        minesweepers.mousewhiches += event.which;
        if (event.which === 3) {
            return;
        }
        if (this.flagged) {
            return;
        }
        this.style.backgroundColor = 'lightgrey';
    });

    td.addEventListener('mouseup', function(event) {
      
        if (!minesweepers.isPresent) {
            return;
        }

        if (this.clicked && minesweepers.mousewhiches == 4) {
            multipleCellClicks(this, i, j);
        }

        minesweepers.mousewhiches = 0;
        
        if (event.which === 3) {
           
            if (this.clicked) {
                return;
            }
            if (this.flagged) {
                this.flagged = false;
                this.textContent = '';
            } else {
                this.flagged = true;
                this.textContent = minesweepers.flag;
            }

            event.preventDefault();
            event.stopPropagation();
          
            return false;
        } 
        else {
            showCellData(this, i, j);
        }
    });

    td.oncontextmenu = function() { 
        return false; 
    };
}

const showCellData =  function(cell, i, j) {
    if (!minesweepers.isPresent) {
        return;
    }

    if (cell.flagged) {
        return;
    }

    cell.clicked = true;

    if (minesweepers.stars[i][j]) {
        cell.style.color = 'red';
        cell.textContent = minesweepers.star;
        gameEnds();
        
    }
    else {
        cell.style.backgroundColor = 'lightgrey';
        num_of_stars = adjacentCells(i, j);
        if (num_of_stars) {
            cell.style.color = minesweepers.colors[num_of_stars];
            cell.textContent = num_of_stars;
        } 
        else {
            selectAdjacentCells(i, j);
        }
    }
}

let adjacentCells = function(row, col) {
    var i, j, num_of_stars;
    num_of_stars = 0;

    for (i=-1; i<2; i++) {
        for (j=-1; j<2; j++) {
            if (minesweepers.stars[row + i] && minesweepers.stars[row + i][col + j]) {
                num_of_stars++;
            }
        }
    }
    return num_of_stars;
}

let setFlags =  function(row, col) {
    var i, j, num_flags;
    num_flags = 0;

    for (i=-1; i<2; i++) {
        for (j=-1; j<2; j++) {
            cell = document.getElementById(tableId(row + i, col + j));
            if (!!cell && cell.flagged) {
                num_flags++;
            }
        }
    }
    return num_flags;
}

const selectAdjacentCells = function (row, col) {
    var i, j, cell;
    
    for (i=-1; i<2; i++) {
        for (j=-1; j<2; j++) {
            if (i === 0 && j === 0) {
                continue;
            }
            cell = document.getElementById(tableId(row + i, col + j));
            if (!!cell && !cell.clicked && !cell.flagged) {
                handleCellClick(cell, row + i, col + j);
            }
        }
    }
}

const multipleCellClicks = function(cell, row, col) {
    if (setFlags(row, col) === adjacentCells(row, col)) {
        selectAdjacentCells(row, col);
    }
}

const gameEnds = function() {
    minesweepers.isPresent = false;
    document.getElementById('minelost').style.display="block";
    
}

const restartGame =  function(){
    window.location.reload();
}

window.addEventListener('load', function() {
    document.getElementById('minelost').style.display="none";
    InitGame();
});