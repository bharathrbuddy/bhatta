$(function() {
 "use strict"

 let timesArr = [];
 displayTimeRange();

 // MatchPeople At lunch function
 const matchPeople = req => opt => ({
  // Calculate the overlap between two blocks
  overlap: opt.end <= req.start || opt.start > req.end ?
   0 : Math.min(req.end, opt.end) - Math.max(req.start, opt.start),
  // The earliest start time of this meeting
  start: Math.max(req.start, opt.start),
  label: `${req.name} - ${opt.name}`
 });

 // check overlap between two people at lunch
 const lunchOverlapRule = ({
  overlap
 }) => overlap >= 30;

 // sort people based on overlap and start time
 const sortPeople = (m1, m2) =>
  // Sort by overlap first
  m2.overlap > m1.overlap ? 1 :
  m2.overlap < m1.overlap ? -1 :
  // Sort by start second
  m2.start > m1.start ? -1 :
  m2.start < m1.start ? 1 :
  0;

 // match Lunch Events functions
/* matchLunchEvent([{
   start: 225,
   end: 285
  }, {
   start: 210,
   end: 270
  }, {
   start: 180,
   end: 240
  }, {
   start: 240,
   end: 300
  }, {
   start: 300,
   end: 360
  }, {
   start: 270,
   end: 330
  }]); */
 //matchLunchEvent([{start:225,end:285},{start:300,end:360},{start:180,end:240}]);
 function matchLunchEvent(arr) {
  $('#lunchEvents').html(); // deleting all the previous nodes and re-creating it.
  arr.map((obj, index) => {
   if (index === 0) {
    obj.name = "Me";
   } else {
    obj.name = "Brilliant Lunch";
   }
  });
  let matchLunch = arr.slice(1).map(matchPeople(arr[0])).filter(lunchOverlapRule).sort(sortPeople);
  renderLunchTimings(arr);

  if (matchLunch.length === 0 || matchLunch === undefined) {
   $('#Me').css({'border': '1px solid #000', 'color': '#000'});
  } else {
   matchLunch[0].start = timeConvert(matchLunch[0].start);
   var matchedItemNum = arr.slice(1).findIndex((item) => {
    return item.start === matchLunch[0].start
   });
   var findItsElem = $('#lunchEvents').children()[arr.slice(1).length - matchedItemNum - 1];
   $('#Me').css('border', '1px solid #73AD21', 'color', '#73AD21');
   $(findItsElem).css({'border': '1px solid #73AD21', 'color': '#73AD21'});
  }

 };


 // render people dom based on their time 
 function renderLunchTimings(ele) {
  var toAddItem = document.createDocumentFragment();
  for (let i =ele.length -1; i>=0; i--) {
   ele[i].start = timeConvert(ele[i].start);
   ele[i].end = timeConvert(ele[i].end);
   ele[i].startTop = Math.floor(drawTable(ele[i].start));
   if (ele[i].startTop >= 350) {
    ele[i].startTop = 328;
   }
   ele[i].endTop = Math.floor(drawTable(ele[i].end));
   var divHeight = ele[i].endTop - ele[i].startTop;

   var newSpan = document.createElement('span');
   newSpan.className = 'lunchcss';
   newSpan.id = ele[i].name;
   newSpan.style.setProperty('top', ele[i].startTop + "px");
   newSpan.style.setProperty('height', divHeight + "px");
   newSpan.innerHTML = ele[i].name;
   toAddItem.appendChild(newSpan);
  }
  $('#lunchEvents').append(toAddItem);
 };

 // find top of each people from start and end based on time range array
 function drawTable(start) {
  var index = timesArr.indexOf(start);
  var ele = $('.timeRange').children()[index];
  var elem = $(ele).offset().top;
  return elem;
 };

 // convert people time into timerange array
 function timeConvert(n, ele) {

  var num = n + 540; // 540 is from morning 9 AM

  var hours = (num / 60);

  if (hours > 12) {
   hours = hours - 12;
  } else if (hours == 12) {
   hours = hours - 12;
  }
  var rhours = Math.floor(hours);

  var minutes = (hours - rhours) * 60;

  var rminutes = Math.round(minutes);

  if (rminutes == 0) {
   rminutes += '0';
  }
  if (rminutes % 2 !== 30) {
   rminutes = 30;
  }
  return "0" + rhours + ":" + rminutes + "PM";

 };


 // calculate time range from 9 am to 9 pm;
 function calculateTimeRangeFromNineMorning() {
   const diff = 30; //minutes interval
   let startTime = 540; // start time based on time 12am to 9 am like 60 *9;
   const ap = ['AM', 'PM']; // AM-PM
   for (let i = 0; startTime < 21.5 * 60; i++) {
   let hh = Math.floor(startTime / 60); // getting hours of day in 0-24 format
   let mm = (startTime % 60); // getting minutes of the hour in 0-55 format
   timesArr[i] = ("0" + (hh % 12)).slice(-2) + ':' + ("0" + mm).slice(-2) + ap[Math.floor(hh / 12)]; // pushing data in array in [00:00 - 12:00 AM/PM format]
   startTime = startTime + diff;
  }
  return timesArr;
 };

 // display time range from 9 am to 9 pm
 function displayTimeRange() {
  let displayItems = calculateTimeRangeFromNineMorning();
  let toAddItems = document.createDocumentFragment();

  for (let i = 0; i < displayItems.length; i++) {
   // Loop to find even, odd sum 
   let newSpan = document.createElement('span');
   if (i % 2 == 0) {
    newSpan.className = 'largeTime';
   } else {
    newSpan.className = 'smallTime';
   }
   newSpan.innerHTML = displayItems[i];
   toAddItems.appendChild(newSpan);
  }
  $('.timeRange').append(toAddItems);
 };

});